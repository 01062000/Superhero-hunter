 import MD5 from "crypto-js/md5.js";

var hash = MD5("1c24f9254e7bfa8a9efc289490f6c3adbca26fb1fc4d99561b17473cd8940a1036f49159c");

async function getSuperherosData(){

    const response = await fetch(`https://gateway.marvel.com:443/v1/public/characters?ts=1&apikey=c4d99561b17473cd8940a1036f49159c&hash=${hash}`);
    const jsonData = await response.json();
    jsonData.data["results"].forEach(element => {
        console.log(element.name);
    });
}
getSuperherosData();
